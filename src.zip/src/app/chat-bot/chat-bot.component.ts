import { Component, Input, OnInit } from '@angular/core';
import { AgentService } from '../service/agent-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms'

@Component({
  selector: 'app-chat-bot',
  standalone: true,
  imports: [FormsModule,CommonModule],
  templateUrl: './chat-bot.component.html',
  styleUrl: './chat-bot.component.scss'
})
export class ChatBotComponent implements OnInit {
  @Input() elementIds: string[] = []; // Accept element IDs from host
  messages: Array<{text: string, isUser: boolean}> = [];
  userInput: string = '';
  
  constructor(private agentService: AgentService) {}
  
  ngOnInit() {
    // this.agentService.setTargetElements(['#product-info', '#main-content']);
    
    if (this.elementIds.length > 0) {
      this.agentService.setTargetElements(this.elementIds);
    }
    
    this.messages.push({
      text: 'Hello! I can answer questions about the content on this page. What would you like to know?',
      isUser: false
    });
  }
  async sendMessage() {
    if (!this.userInput.trim()) return;
    
    // Add user message
    this.messages.push({
      text: this.userInput,
      isUser: true
    });
    
    try {
      // Process query and get response
      const response = await this.agentService.processQuery(
        this.userInput);
        this.userInput =' ';
      // Add bot response
      this.messages.push({
        text: response,
        isUser: false
      });
    } catch (error) {
      console.error('Error processing query:', error);
      this.messages.push({
        text: 'Sorry, I encountered an error processing your request.',
        isUser: false
      });
    }
    
    this.userInput = '';
  }
}