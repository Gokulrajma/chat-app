import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
// import sanitizeHtml from 'sanitize-html';

@Injectable({
  providedIn: 'root'
})
export class AgentService {
  private SERVER_URL = 'http://localhost:3000';
  private targetElements: string[] = [];
  private isInitialized = false;
  private sessionId = '';

  constructor(private http: HttpClient) {}

  setTargetElements(selectors: string[]) {
    this.targetElements = selectors;
    if (!this.isInitialized) {
      this.initializeModel();
    }
  }

  private async initializeModel() {
    const content = this.extractDOMContent();
    const prompt = `
    Context from webpage:
    ${content}
    Please answer the question based on the context provided.
    Remember this and keep this as your knowledge base for the followup questions
    `;

    try {
      const response = await this.http.post<{ sessionId: string, message: string }>(
        `${this.SERVER_URL}/api/generate/initialize`,
        { prompt }
      ).toPromise();

      if (response?.sessionId) {
        this.sessionId = response.sessionId;
        return response.message;
      }
      return 'No response received';
    } catch (error) {
      console.error('Error initializing chat:', error);
      return 'Sorry, there was an error initializing the chat.';
    }
  }

  private extractDOMContent(): string {
    let content = '';
    this.targetElements.forEach(selector => {
      const element = document.querySelector(selector);
      if (element) {
        // const sanitizedContent = sanitizeHtml(element.outerHTML, {
        //   allowedTags: sanitizeHtml.defaults.allowedTags.concat(['img']),
        //   allowedAttributes: {
        //     '*': ['style', 'class'],
        //     'img': ['src', 'alt']
        //   }
        // });
        content += `Content from ${selector}:\n${element.innerHTML}\n\n`;
      }
    });
    return content;
  }

  async processQuery(query: string): Promise<string> {
    const prompt = `
      User question: ${query}
      Please answer the question based on the context provided Initially.
    `;
    try {
      const response = await this.http.post<{ text: string }>(
        `${this.SERVER_URL}/api/generate/chat`,
        {
          sessionId: this.sessionId,
          query
        }
      ).toPromise();

      // Sanitize the response text to remove HTML tags
      // const sanitizedText = sanitizeHtml(response?.text || '', {
      //   allowedTags: [], // Remove all HTML tags
      //   allowedAttributes: {}
      // });

      return response?.text || 'No response received';
    } catch (error) {
      console.error('Error sending message:', error);
      return 'Sorry, there was an error processing your message.';
    }
  }
}