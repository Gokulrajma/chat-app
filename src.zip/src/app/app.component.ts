import { AfterViewInit, Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { ChatBotComponent } from './chat-bot/chat-bot.component';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
interface DailyValue {
  [date: string]: { [key: string]: any };
}

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, ChatBotComponent,FormsModule,CommonModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})
export class AppComponent implements AfterViewInit {
  isChatBotOpen = false;
  isContentLoaded = false;

  openChatBot() {
    this.isChatBotOpen = ! this.isChatBotOpen;
  }
  ngAfterViewInit() {
    // Set isContentLoaded to true when the view is fully initialized
    this.isContentLoaded = true;
  }

  title = 'patient-app';
  sections = [
    { name: 'Fluid/BP', data: this.generateDummyData('Fluid/BP'), expanded: false },
    { name: 'Adequacy', data: this.generateDummyData('Adequacy'), expanded: false },
    // { name: 'Access', data: this.generateDummyData('Access'), expanded: false },
    // { name: 'Anemia', data: this.generateDummyData('Anemia'), expanded: false },
    // { name: 'Nutrition', data: this.generateDummyData('Nutrition'), expanded: false },
  ];

  Object = Object;

  generateDummyData(sectionName: string): DailyValue {
    const data: DailyValue = {};
    const numDays = 20;
    const startDate = new Date();

    for (let i = 0; i < numDays; i++) {
      const currentDate = new Date(startDate);
      currentDate.setDate(startDate.getDate() - i);
      const dateString = currentDate.toISOString().slice(0, 10);
      data[dateString] = {};

      switch (sectionName) {
        case 'Fluid/BP':
          data[dateString] = {
            'Actual Tx Time': '2h', 'Prescribed Tx Time': '2.5h', IDWG: (Math.random() + 0.2).toFixed(1), 'Pre Wt': (70 + Math.random() * 2).toFixed(1), 'Target Wt': '69.5', 'Post Wt': (69 + Math.random()).toFixed(1), 'Actual UFR (ml/kg/hr)': (10 + Math.random() * 2).toFixed(1)
          };
          break;
        case 'Adequacy':
          data[dateString] = {
            'Actual Tx Time': '2h', BUN: (20 + Math.random() * 5).toFixed(1), URR: (70 + Math.random() * 5).toFixed(1), CREATININE: (1.2 + Math.random() * 0.3).toFixed(2), 'spKdt/V Dialysis': (1.5 + Math.random() * 0.2).toFixed(2), 'spKt/V Total': (1.6 + Math.random() * 0.2).toFixed(2)
          };
          break;
        case 'Access':
          data[dateString] = {
            'Access Type Used': 'AV Fistula', 'Prescribed BFR': '350', 'Avg BFR': (350 + Math.random() * 20).toFixed(1), 'Avg Arterial Pressure': (-250 + Math.random() * 50).toFixed(1), 'Used Arterial Needle': '15G', 'Avg Venous Pressure': (150 + Math.random() * 30).toFixed(1), 'Used Venous Needle': '16G'
          };
          break;
        case 'Anemia':
          data[dateString] = {
            WBC: (7 + Math.random() * 2).toFixed(1), HEMOGLOBIN: (10 + Math.random() * 2).toFixed(1), 'Administered Mircera': '30mcg', 'Rx 30mcg IV 1x/2 weeks': 'Yes', 'PLATELET-CT': (200 + Math.random() * 50).toFixed(1), 'IRON SATURATION': (30 + Math.random() * 10).toFixed(1), FERRITIN: (500 + Math.random() * 200).toFixed(1), 'Administered Venofer': '100mg'
          };
          break;
        case 'Nutrition':
          data[dateString] = {
            'HGB A1c (GLYCOHGB)': (6.5 + Math.random()).toFixed(1), POTASSIUM: (4 + Math.random()).toFixed(1), CO2: (25 + Math.random() * 3).toFixed(1), ALBUMIN: (3.5 + Math.random()).toFixed(1)
          };
          break;
      }
    }
    return data;
  }

  goToSection(sectionName: string) {
    const element = document.getElementById(sectionName);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  getDates(data: DailyValue): string[] {
    return Object.keys(data);
  }

  getVitalValue(data: DailyValue, date: string, vital: string): any {
    return data[date] ? data[date][vital] : '-';
  }

  getKeys(obj: any): string[] {
    return Object.keys(obj);
  }
}